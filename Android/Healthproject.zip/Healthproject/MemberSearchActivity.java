package com.naver.yhoo2468;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.naver.yhoo2468.R.layout;
import com.naver.yhoo2468.entities.User;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.SimpleCursorAdapter;

public class MemberSearchActivity extends Activity {
    ListView listview;
    Button close;
    Button delete;
	final Context context = this;
	
	
	 protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.member_search);
	        listview= (ListView) findViewById(R.id.listview);
	        close = (Button) findViewById(R.id.close);
	        delete = (Button) findViewById(R.id.delete);
	        close.setOnClickListener( bClick );
	        delete.setOnClickListener( bClick );
	        memberSearch();
	        
	 } 
	 Button.OnClickListener bClick = new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				switch (v.getId()) {
				case R.id.close:
						finish();
						break;
				case R.id.delete:
					memberCheckBox();
					break;
    }
   }
 };
 private void memberCheckBox() {
	 int checkboxcount = listview.getChildCount(); //checkbox total count
	 int checkedcount = 0;
	 CheckBox listcheckbox;
	 final List<Integer> pklist = new ArrayList<Integer>();
	
	 for ( int i = 0 ; i < checkboxcount ; i ++ ){
		 listcheckbox = (CheckBox) listview.getChildAt(i).findViewById(R.id.showcheckbox);
		 final int selectedpk = (int) listview.getAdapter().getItemId(i);
		 if ( listcheckbox.isChecked()){
			 pklist.add(selectedpk);
			 checkedcount ++;
			 Log.d("---->selectedpk", "-->"+selectedpk);
			 Log.d("---->checkedcount", "-->"+checkedcount);
			 listcheckbox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				 
					public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
						// 체크를 할 때
						if (isChecked) {
							for (int i = 0; i < pklist.size(); i++) {
								if (pklist.get(i) == selectedpk) {
									return;
								}
							}
							pklist.add(selectedpk);
						// 체크가 해제될 때
						} else {
							for (int i =0; i < pklist.size(); i++) {
								if (pklist.get(i) == selectedpk) {
									pklist.remove(i);
									break;
								}
							}
						}
					}
				});
		 }
	 }
	 if( checkedcount > 0 ){
		 AlertDialog.Builder dialog = new AlertDialog.Builder(context);
			dialog.setMessage("Are you Right?");
			dialog.setTitle("Warning");
			dialog.setIcon(R.drawable.ic_launcher);
			dialog.setPositiveButton("No", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					return;
				}
			});
			dialog.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					memberDelete((ArrayList<Integer>) pklist);
					memberSearch();
					return;
				}
			});
			dialog.create();
			dialog.show();
	 }
	 else {
		 AlertDialog.Builder dialog = new AlertDialog.Builder(context);
			dialog.setMessage("Checked please for delete");
			dialog.setTitle("Warning");
			dialog.setIcon(R.drawable.ic_launcher);
		    dialog.setNegativeButton("ok", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					return;
				}
			});
			dialog.create();
			dialog.show();
	 }
 }
 private void memberDelete(ArrayList<Integer> pklist){
	 SQLiteDAO obj;
	 obj = new SQLiteDAO( this ); 
	 SQLiteDatabase db = obj.getWritableDatabase();
	 for (Integer id : pklist){
	 String sql = "delete from user where _id = "+id+" ";
	 Log.d("sql =====", "sql--->"+sql);
	 try {
    	 db.execSQL(sql);
	} catch (Exception e) {
		Log.d("----->", e.getMessage());
	}
	 }
	 db.close();
 }
 private void memberSearch(){
	 SQLiteDAO obj; //DAO only return after check 
	 obj = new SQLiteDAO( this ); 
	 SQLiteDatabase db = obj.getWritableDatabase(); //db execute -> db cunnect
	 String sql = "select _id,id,name,password,image from user";
	 
	 Cursor c = db.rawQuery(sql, null); // = Result Set  -> You have something if rs or c excute
	 startManagingCursor(c);
	 String from[] = new String [] {"image","_id","id","name","password"};
	 int to[] =  new int [] {R.id.showimage,R.id.showno,R.id.showid,R.id.showname,R.id.showpassword};
	 SimpleCursorAdapter adapter = new SimpleCursorAdapter(listview.getContext(),
			 R.layout.membersearch_detail,c,from,to);
	 Log.d("----------->", "COUNT+++"+c.getCount());
	 adapter.setViewBinder(new SimpleCursorAdapter.ViewBinder() {
		
		@Override
		public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
			if ( view.getId() == R.id.showimage){
				ImageView IV = (ImageView) view;
				byte[] outImage = cursor.getBlob(4);
				Bitmap theimage = 
				BitmapFactory.decodeByteArray(outImage, 0, outImage.length);
				IV.setImageBitmap(theimage);
				return true;
			}
			return false;
		}
	});
	 listview.setAdapter(adapter);
	 listview.setTextFilterEnabled(true);
	 listview.setSelectionFromTop(10,1);
	 listview.setOnItemLongClickListener( new OnItemLongClickListener() {

		@Override
		public boolean onItemLongClick(AdapterView<?> arg0, View view, int position, long id) {
			int code = (int) listview.getItemIdAtPosition(position);
			Log.d("-------------->", "---listview listener no = ---->"+code);
			Intent intent = new Intent(MemberSearchActivity.this,MemberUpdateActivity.class);
			intent.putExtra("code",code);
			startActivity(intent);
			return false;
		}
	} );
 }
}
 





