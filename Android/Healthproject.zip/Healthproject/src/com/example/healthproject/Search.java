package com.example.healthproject;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff.Mode;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Search extends Activity implements OnGestureListener{
	EditText search;
	Button searchbtn;
	WebView web;
	
	ImageView tab1;
	ImageView tab2;
	ImageView tab3;
	ImageView tab4;
	TextView view;
	InputMethodManager imm;
	public static Activity Search;
	
	LinearLayout baselayout;
	final Context context = this;
	SharedPreferences sharedpreferences; //Read session data
 	public static final String MyPREFERENCES = "mPrefs"; //Read session data
 	private GestureDetector gestureScanner;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.search);
		Search = this;
		gestureScanner = new GestureDetector(this);
		try {
            getActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
            getActionBar().setCustomView(R.layout.title);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
		search =(EditText) findViewById(R.id.search);
		web =(WebView) findViewById(R.id.web);
		web.getSettings().setJavaScriptEnabled(true);
		searchbtn =(Button) findViewById(R.id.searchbtn);
		searchbtn.setOnClickListener( bClick );
		imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		  tab1=(ImageView) findViewById(R.id.tab1);
			tab2=(ImageView) findViewById(R.id.tab2);
			tab3=(ImageView) findViewById(R.id.tab3);
			tab4 = (ImageView) findViewById(R.id.tab4);
	        
	        tab1.setOnTouchListener(touch);
			tab2.setOnTouchListener(touch);
			tab3.setOnTouchListener(touch);
			tab2.setVisibility(view.VISIBLE);
			
			baselayout = (LinearLayout) findViewById(R.id.baselayout);
		    baselayout.setOnClickListener( bClick );
		    web.setOnClickListener( bClick );
		    
	        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
			String login = sharedpreferences.getString("sessionid", "");
			if(!login.equals("")){
				Log.d("---login---", login);
				tab2.setVisibility(view.GONE);
				tab4.setVisibility(view.VISIBLE);
				tab4.setOnTouchListener(touch);
			}
			else{
				tab2.setVisibility(view.VISIBLE);
				tab4.setVisibility(view.GONE);
			}
	}
	    
		
OnTouchListener touch = new OnTouchListener() {
	
	@Override
	public boolean onTouch(View v, MotionEvent event) {
		switch (v.getId()) {
		case R.id.tab1:
			if(event.getAction()==MotionEvent.ACTION_DOWN) {
				tab1.setPadding(0, 0, 0, 0);
				tab1.setColorFilter(111111,Mode.SRC_OVER);
			}
			else if (event.getAction()==MotionEvent.ACTION_UP){
				tab1.setPadding(3, 3, 3, 3);
				tab1.setColorFilter(111111,Mode.SRC_OVER);
				Intent intent11 = new Intent( Search.this, MainActivity.class);
				intent11.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
				startActivity(intent11);
			}
			break;
		case R.id.tab2:
			if(event.getAction()==MotionEvent.ACTION_DOWN) {
				tab2.setPadding(0, 0, 0, 0);
				tab2.setColorFilter(111111,Mode.SRC_OVER);
			}
			else if (event.getAction()==MotionEvent.ACTION_UP){
				tab2.setPadding(3, 3, 3, 3);
				tab2.setColorFilter(111111,Mode.SRC_OVER);
				Intent intent8 = new Intent( Search.this, MemberLoginActivity.class);
				intent8.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
				startActivity(intent8);
			}
			break;
		case R.id.tab3:
			if(event.getAction()==MotionEvent.ACTION_DOWN) {
				tab3.setPadding(0, 0, 0, 0);
				tab3.setColorFilter(111111,Mode.SRC_OVER);
			}
			else if (event.getAction()==MotionEvent.ACTION_UP){
				tab3.setPadding(3, 3, 3, 3 );
				tab3.setColorFilter(111111,Mode.SRC_OVER);
				web.setVisibility(view.GONE);
			}
			break;
		case R.id.tab4:
			if(event.getAction()==MotionEvent.ACTION_DOWN) {
				tab4.setPadding(0, 0, 0, 0);
				tab4.setColorFilter(111111,Mode.SRC_OVER);
			}
			else if (event.getAction()==MotionEvent.ACTION_UP){
				tab4.setPadding(2, 2, 2, 2);
				tab4.setColorFilter(111111,Mode.SRC_OVER);
				Intent intent10 = new Intent( Search.this, MemberRecord.class);
				intent10.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
				startActivity(intent10);
			}
			break;
	}
		return true;
	}
};
	Button.OnClickListener bClick = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
			switch (v.getId()) {
			case R.id.searchbtn:
				if ( search.getText().toString().equals("")) {
					AlertDialog.Builder dialog = new AlertDialog.Builder(context);
					dialog.setMessage("Input search data");
					dialog.setTitle("Warning");
					dialog.setIcon(R.drawable.icon);
					dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							return;
						}
					});
					dialog.create();
					dialog.show();
				}
				else{
				web.setWebViewClient(new WebViewClient());
			    WebSettings webSettings = web.getSettings();
				web.loadUrl("https://www.youtube.com/results?search_query="+search.getText());
				web.setVisibility(view.VISIBLE);
				}
				break;
			default:
				break;
			}
		}
	};

	@Override
	public void onBackPressed() {
		web.setVisibility(view.GONE);
		finish();
	}

	@Override
	public boolean onDown(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean onTouchEvent(MotionEvent me){
		return gestureScanner.onTouchEvent(me);
	}
	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onLongPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onShowPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}
}


