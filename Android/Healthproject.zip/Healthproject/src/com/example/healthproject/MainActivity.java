package com.example.healthproject;


import java.util.ArrayList;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff.Mode;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnGestureListener{
	ImageView exercise;
	ImageView food;
	ImageView beforeafter;
	ImageView tab1;
	ImageView tab2;
	ImageView tab3;
	ImageView tab4;
	
	WebView foodview;
	Dialog Dialog;
	InputMethodManager imm;
	
	ListView list;
	TextView view;
	private GestureDetector gestureScanner;
	SharedPreferences sharedpreferences; //Read session data
	public static final String MyPREFERENCES = "mPrefs"; //Read session data
	private BackPressCloseHandler backPressCloseHandler;
	private long backKeyPressedTime = 0;
	private Toast toast;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		try {
            getActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
            getActionBar().setCustomView(R.layout.title);
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
//		closeIntent();
		
		gestureScanner = new GestureDetector(this);
		imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		setContentView(R.layout.activity_main);
		exercise=(ImageView) findViewById(R.id.exercise);
		food=(ImageView) findViewById(R.id.food);
		beforeafter=(ImageView) findViewById(R.id.beforeafter);
		tab1=(ImageView) findViewById(R.id.tab1);
		tab2=(ImageView) findViewById(R.id.tab2);
		tab3=(ImageView) findViewById(R.id.tab3);
		tab4 = (ImageView) findViewById(R.id.tab4);
		
		foodview=(WebView) findViewById(R.id.foodview);
		foodview.getSettings().setJavaScriptEnabled(true); //자바 스크립트 enable
		foodview.setOnTouchListener(touch);
		
		exercise.setOnTouchListener(touch);
		food.setOnTouchListener(touch);
		
		beforeafter.setOnTouchListener(touch);
		tab1.setOnTouchListener(touch);
		tab2.setOnTouchListener(touch);
		tab3.setOnTouchListener(touch);
		tab2.setVisibility(view.VISIBLE);
		
		backPressCloseHandler = new BackPressCloseHandler(this);
		sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
		String login = sharedpreferences.getString("sessionid", "");
		if(!login.equals("")){
			Log.d("---login---", login);
			tab2.setVisibility(view.GONE);
			tab4.setVisibility(view.VISIBLE);
			tab4.setOnTouchListener(touch);
		}
		else{
			tab2.setVisibility(view.VISIBLE);
			tab4.setVisibility(view.GONE);
		}
	}
	
private void closeIntent() {
	Intent intent  = getIntent();
	intent.getExtras().toString();
		Search.Search.finish();
		
	}

OnTouchListener touch = new OnTouchListener() {
		
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			switch (v.getId()) {
			case R.id.exercise:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					exercise.setPadding(0, 0, 0, 0);
					exercise.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					exercise.setPadding(3, 3, 3, 3);
					exercise.setColorFilter(111111,Mode.SRC_OVER);
					Intent intent = new Intent(MainActivity.this, ExerCiseActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent);
				}
				break;
			case R.id.food:
			    if(event.getAction()==MotionEvent.ACTION_DOWN) {
					food.setPadding(0, 0, 0, 0);
					food.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					food.setPadding(3, 3, 3, 3);
					food.setColorFilter(111111,Mode.SRC_OVER);
				}
			    foodview.setWebViewClient(new WebViewClient());
			    WebSettings webSettings = foodview.getSettings();
				foodview.loadUrl("http://cook.miznet.daum.net/theme/themeRecipeList.do?themeId=8&pageNo=1#list");
				foodview.setVisibility(view.VISIBLE);
				break;
			case R.id.beforeafter:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					beforeafter.setPadding(0, 0, 0, 0);
					beforeafter.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					beforeafter.setPadding(3, 3, 3, 3);
					beforeafter.setColorFilter(111111,Mode.SRC_OVER);
					showListDialog( );
				}
				break;
			case R.id.tab1:
				foodview.setVisibility(view.GONE);
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab1.setPadding(0, 0, 0, 0);
					tab1.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab1.setPadding(3, 3, 3, 3);
					tab1.setColorFilter(111111,Mode.SRC_OVER);
				}
				break;
			case R.id.tab2:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab2.setPadding(0, 0, 0, 0);
					tab2.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab2.setPadding(3, 3, 3, 3);
					tab2.setColorFilter(111111,Mode.SRC_OVER);
					Intent intent1 = new Intent( MainActivity.this, MemberLoginActivity.class);
					intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent1);
				}
				break;
			case R.id.tab3:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab3.setPadding(0, 0, 0, 0);
					tab3.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab3.setPadding(3, 3, 3, 3 );
					tab3.setColorFilter(111111,Mode.SRC_OVER);
					Intent intent2 = new Intent( MainActivity.this, Search.class);
					intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent2);
				}
				break;
			case R.id.tab4:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab4.setPadding(0, 0, 0, 0);
					tab4.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab4.setPadding(2, 2, 2, 2);
					tab4.setColorFilter(111111,Mode.SRC_OVER);
					Intent intent3 = new Intent( MainActivity.this, MemberRecord.class);
					intent3.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent3);
				}
				break;
			default:
				break;
			}
			return gestureScanner.onTouchEvent(event);
		}
	};
	
	private void showListDialog( ) {
		ArrayList <String> trainerlist = new ArrayList<String>();
		String  trainer = "재미어트,TRIGER,XHIT,TEAMBONO,DANO,DEATHRUN,다이어트학교TV";
		String [] trainer1 = new String[trainer.length() ];
		 trainer1 = trainer.split(",");
		for ( int i = 0 ; i < trainer1.length ;i++ ){
			trainerlist.add(trainer1[i]);
			}
		LayoutInflater li = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View v = li.inflate(R.layout.trainer_view,null,false);
		Dialog = new Dialog(MainActivity.this);
		Dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		Dialog.setContentView(v);
		Dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
//		Dialog.getWindow().setBackgroundDrawable
//        (new ColorDrawable(android.graphics.Color.RED));
		list = (ListView) Dialog.findViewById(R.id.list);
		list.setAdapter(new ArrayAdapter<String>(this,R.layout.trainer_view,trainerlist){
			@Override
			public View getView(int position, View convertView, ViewGroup parent){
				TextView txt = new TextView(this.getContext());
				txt.setTextSize(30);
				txt.setText(this.getItem(position));
				return txt;
			}
		});
		list.setSelectionFromTop(0, 1);
		list.setOnItemClickListener(new OnItemClickListener() {
 
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				String selecteditem = (String) arg0.getAdapter().getItem((int) arg3);
				view = (TextView) Dialog.findViewById(R.id.view);
				view.setText(selecteditem);
				view.setVisibility(View.VISIBLE);

				foodview.setWebViewClient(new WebViewClient());
			    WebSettings webSettings = foodview.getSettings();
				if ( selecteditem.equals("재미어트")){
					foodview.loadUrl("https://www.youtube.com/channel/UCrFFbADYO1jrXxefP9MivWA");
					foodview.setVisibility(view.VISIBLE);
					Dialog.dismiss();
				}
				if ( selecteditem.equals("TRIGER")){
					foodview.loadUrl("https://www.youtube.com/channel/UCoyogo_Fg-Z5jDOQz6Rt6eA");
					foodview.setVisibility(view.VISIBLE);
					Dialog.dismiss();
				}
				if ( selecteditem.equals("TEAMBONO")){
					foodview.loadUrl("https://www.youtube.com/channel/UC7wdnqkhpz6X7apXSBytq4Q");
					foodview.setVisibility(view.VISIBLE);
					Dialog.dismiss();
				}
				if ( selecteditem.equals("DANO")){
					foodview.loadUrl("https://www.youtube.com/channel/UCxM_KJ601hwrOpjVC07iMVQ");
					foodview.setVisibility(view.VISIBLE);
					Dialog.dismiss();
				}
				if ( selecteditem.equals("DEATHRUN")){
					foodview.loadUrl("https://www.youtube.com/channel/UCHHGX6n-7T01PV9P2zquXvA");
					foodview.setVisibility(view.VISIBLE);
					Dialog.dismiss();
				}
				if ( selecteditem.equals("다이어트학교TV")){
					foodview.loadUrl("https://www.youtube.com/channel/UCDNbJbeMYKWbL4uqoNEVxtw");
					foodview.setVisibility(view.VISIBLE);
					Dialog.dismiss();
				}
				if ( selecteditem.equals("XHIT")){
					foodview.loadUrl("https://www.youtube.com/user/XFitDaily");
					foodview.setVisibility(view.VISIBLE);
					Dialog.dismiss();
				}
			}
		});
		Dialog.show();
		Dialog.setCancelable(true);
		Dialog.setCanceledOnTouchOutside(true);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		return super.onOptionsItemSelected(item);
	}
	
	
	@Override
	public void onBackPressed() {
			foodview.setVisibility(view.GONE);
			if (System.currentTimeMillis() > backKeyPressedTime + 2000) {
				backKeyPressedTime = System.currentTimeMillis();
				showGuide();
				return;
			}
			if (System.currentTimeMillis() <= backKeyPressedTime + 2000) {
				moveTaskToBack(true); 
				finish();
				android.os.Process.killProcess(android.os.Process.myPid());
				toast.cancel();
			}
	}
	
	public void showGuide() {
		toast = Toast.makeText(MainActivity.this,
				" One more back press app exit ", Toast.LENGTH_SHORT);
		toast.show();
	}
	
	@Override
	public boolean onDown(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean onTouchEvent(MotionEvent me){
		return gestureScanner.onTouchEvent(me);
	}
	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onLongPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onShowPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}
}
