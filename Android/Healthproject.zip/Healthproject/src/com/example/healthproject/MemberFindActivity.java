package com.example.healthproject;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PorterDuff.Mode;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MemberFindActivity extends Activity implements OnGestureListener{
	EditText name;
	EditText id;
	EditText name2;
	
	Button close;
	Button join;
	Button login;
	Button idchk;
	Button pwchk;
	
	ImageView tab1;
	ImageView tab2;
	ImageView tab3;
	ImageView tab4;
	TextView view;
	InputMethodManager imm;
	LinearLayout baselayout;
	final Context context = this;

	private static final int SWIPE_MIN_DISTANCE = 120;
	private static final int SWIPE_MAX_OFF_PATH = 250;
	private static final int SWIPE_THRESHOLD_VELOCITY = 200;
	private GestureDetector gestureScanner;
//	
	 protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.member_find);
	    	gestureScanner = new GestureDetector(this);
	        try {
	            getActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
	            getActionBar().setCustomView(R.layout.title);
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }
	        id = (EditText) findViewById(R.id.id);
	        name = (EditText) findViewById(R.id.name);
	        name2 = (EditText) findViewById(R.id.name2);
	        close = (Button) findViewById(R.id.close);
	        join = (Button) findViewById(R.id.join);
	        login = (Button) findViewById(R.id.login);
	        idchk = (Button) findViewById(R.id.idchk);
	        pwchk = (Button) findViewById(R.id.pwchk);
	        baselayout = (LinearLayout) findViewById(R.id.baselayout);
	        baselayout.setOnClickListener( bClick );
	        
			close.setOnClickListener( bClick );
			join.setOnClickListener( bClick );
			login.setOnClickListener( bClick );
			idchk.setOnClickListener( bClick );
			pwchk.setOnClickListener( bClick );
			
			tab1=(ImageView) findViewById(R.id.tab1);
			tab2=(ImageView) findViewById(R.id.tab2);
			tab3=(ImageView) findViewById(R.id.tab3);
			tab4 = (ImageView) findViewById(R.id.tab4);
	        
	        tab1.setOnTouchListener(touch);
			tab2.setOnTouchListener(touch);
			tab3.setOnTouchListener(touch);
			tab2.setVisibility(view.VISIBLE);
			tab4.setVisibility(view.GONE);
			
			imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
	 } 
	 OnTouchListener touch = new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (v.getId()) {
				case R.id.tab1:
					if(event.getAction()==MotionEvent.ACTION_DOWN) {
						tab1.setPadding(0, 0, 0, 0);
						tab1.setColorFilter(111111,Mode.SRC_OVER);
					}
					else if (event.getAction()==MotionEvent.ACTION_UP){
						tab1.setPadding(2, 2, 2, 2);
						tab1.setColorFilter(111111,Mode.SRC_OVER);
						Intent intent11 = new Intent( MemberFindActivity.this, MainActivity.class);
						intent11.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intent11);
					}
					break;
				case R.id.tab2:
					if(event.getAction()==MotionEvent.ACTION_DOWN) {
						tab2.setPadding(2, 2, 2, 2);
						tab2.setColorFilter(111111,Mode.SRC_OVER);
					}
					else if (event.getAction()==MotionEvent.ACTION_UP){
						tab2.setPadding(0, 0, 0, 0);
						tab2.setColorFilter(111111,Mode.SRC_OVER);
						Intent intent8 = new Intent(  MemberFindActivity.this, MemberLoginActivity.class);
						intent8.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intent8);
					}
					
					break;
				case R.id.tab3:
					if(event.getAction()==MotionEvent.ACTION_DOWN) {
						tab3.setPadding(2, 2, 2, 2);
						tab3.setColorFilter(111111,Mode.SRC_OVER);
					}
					else if (event.getAction()==MotionEvent.ACTION_UP){
						tab3.setPadding(0, 0, 0, 0);
						tab3.setColorFilter(111111,Mode.SRC_OVER);
						Intent intent9 = new Intent(  MemberFindActivity.this, Search.class);
						intent9.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intent9);
					}
					
					break;
				}
				return true;
			}
		};
	 Button.OnClickListener bClick = new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
				switch (v.getId()) {
				case R.id.close:
						finish();
						break;
				case R.id.login:
					Intent intent = new Intent(MemberFindActivity.this, MemberLoginActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent);
					break;
				case R.id.join:
					Intent intent1 = new Intent(MemberFindActivity.this, MemberInsertActivity.class);
					intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent1);
					break;
				case R.id.idchk:
					memberIdCheck(name.getText().toString());
					break;
				case R.id.pwchk:
					memberPwdCheck(id.getText().toString(),name2.getText().toString());
					break;
				
     }
	}
  };
  private void memberIdCheck(String idchk){
		 boolean chk = false;
		 SQLiteDAO obj; 
		 obj = new SQLiteDAO( this ); 
		 SQLiteDatabase db = obj.getWritableDatabase(); 
		 String sql = "select id from member where name = '"+idchk+"'";
		 Log.d("---------->","IDCHECK"+sql);
		 try {
			 Cursor cursor = db.rawQuery(sql, null);
			 String message = "Your id is ";
			 if(cursor.moveToNext()){
				 AlertDialog.Builder dialog = new AlertDialog.Builder(context);
					dialog.setMessage(message+cursor.getString(0));
					dialog.setTitle("Alert");
					dialog.setIcon(R.drawable.icon);
					dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							name.setText("");
							return ;
						}
					});
					dialog.create();
					dialog.show();
			 }
			 else{
				 AlertDialog.Builder dialog = new AlertDialog.Builder(context);
					dialog.setMessage(message+"not found");
					dialog.setTitle("Alert");
					dialog.setIcon(R.drawable.icon);
					dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							name.setText("");
							return ;
						}
					});
					dialog.create();
					dialog.show();
			 }
				
			 db.close();
		} catch (Exception e) {
			chk = false;
			Log.d("====>",e.getMessage());
		}
		 return;
	 }
  private void memberPwdCheck(String idchk, String name){
	  boolean chk = false;
	  SQLiteDAO obj; 
	  obj = new SQLiteDAO( this ); 
	  SQLiteDatabase db = obj.getWritableDatabase(); 
	  String sql = "select password from member where id = '"+idchk+"' and name = '"+name+"' ";
	  Log.d("---------->","PWDCHECK"+sql);
	  try {
		  Cursor cursor = db.rawQuery(sql, null);
		  String message = "Your password is ";
		  if(cursor.moveToNext()){
			  AlertDialog.Builder dialog = new AlertDialog.Builder(context);
			  dialog.setMessage(message+cursor.getString(0));
			  dialog.setTitle("Alert");
			  dialog.setIcon(R.drawable.icon);
			  dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
				  
				  @Override
				  public void onClick(DialogInterface dialog, int which) {
					  id.setText("");
					  name2.setText("");
					  return ;
				  }
			  });
			  dialog.create();
			  dialog.show();
		  }
		  else{
			  AlertDialog.Builder dialog = new AlertDialog.Builder(context);
			  dialog.setMessage(message+"not found");
			  dialog.setTitle("Alert");
			  dialog.setIcon(R.drawable.icon);
			  dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
				  
				  @Override
				  public void onClick(DialogInterface dialog, int which) {
					  id.setText("");
					  name2.setText("");
					  return ;
				  }
			  });
			  dialog.create();
			  dialog.show();
		  }
		  
		  db.close();
	  } catch (Exception e) {
		  chk = false;
		  Log.d("====>",e.getMessage());
	  }
	  return;
  }
  @Override
  public void onBackPressed() {
	  finish();
	  super.onBackPressed();
 	}
@Override
public boolean onDown(MotionEvent e) {
	// TODO Auto-generated method stub
	return false;
}
public boolean onTouchEvent(MotionEvent me){
	return gestureScanner.onTouchEvent(me);
}
@Override
public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
	// TODO Auto-generated method stub
	return false;
}
@Override
public void onLongPress(MotionEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
	// TODO Auto-generated method stub
	return false;
}
@Override
public void onShowPress(MotionEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public boolean onSingleTapUp(MotionEvent e) {
	// TODO Auto-generated method stub
	return false;
}
}
