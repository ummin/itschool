package com.example.healthproject;

import java.util.ArrayList;
import java.util.List;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PorterDuff.Mode;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class MemberRecord extends Activity implements OnGestureListener{
    ListView listview;
    Button close;
    Button delete;
    Button record;
    Button logout;
    TextView userv;
    
    ImageView tab1;
	ImageView tab2;
	ImageView tab3;
	ImageView tab4;
	TextView view;
	InputMethodManager imm;
	
	final Context context = this;
	SharedPreferences sharedpreferences; //Read session data
 	public static final String MyPREFERENCES = "mPrefs"; //Read session data
 	private GestureDetector gestureScanner;
 	
	 protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.member_record);
	        gestureScanner = new GestureDetector(this);
	        try {
	            getActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
	            getActionBar().setCustomView(R.layout.title);
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }
	        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
	        listview= (ListView) findViewById(R.id.listview);
	        userv= (TextView) findViewById(R.id.userv);
	        close = (Button) findViewById(R.id.close);
	        delete = (Button) findViewById(R.id.delete);
	        record = (Button) findViewById(R.id.record);
	        logout = (Button) findViewById(R.id.logout);
	        close.setOnClickListener( bClick );
	        delete.setOnClickListener( bClick );
	        record.setOnClickListener( bClick );
	        logout.setOnClickListener( bClick );
	        
	        tab1=(ImageView) findViewById(R.id.tab1);
			tab2=(ImageView) findViewById(R.id.tab2);
			tab3=(ImageView) findViewById(R.id.tab3);
			tab4 = (ImageView) findViewById(R.id.tab4);
	        
	        tab1.setOnTouchListener(touch);
			tab2.setOnTouchListener(touch);
			tab3.setOnTouchListener(touch);
			tab2.setVisibility(view.VISIBLE);
			
	        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
	        String userid = sharedpreferences.getString("sessionid", "");
	        memberSearch(userid);
	        userv.setText(userid);
	        tab2.setVisibility(view.GONE);
			tab4.setVisibility(view.VISIBLE);
			tab4.setOnTouchListener(touch);
	 } 
	 Button.OnClickListener bClick = new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				switch (v.getId()) {
				case R.id.close:
						finish();
						break;
				case R.id.delete:
					memberCheckBox();
					break;
				case R.id.record:
					Intent intent = new Intent(MemberRecord.this, RecordDetail.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent);
					break;
				case R.id.logout:
					 AlertDialog.Builder dialog = new AlertDialog.Builder(context);
						dialog.setMessage("Are you Right?");
						dialog.setTitle("Warning");
						dialog.setIcon(R.drawable.icon);
						dialog.setPositiveButton("No", new DialogInterface.OnClickListener() {
							
							@Override
							public void onClick(DialogInterface dialog, int which) {
								return;
							}
						});
						dialog.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
							
							@Override
							public void onClick(DialogInterface dialog, int which) {
								SharedPreferences.Editor editor = sharedpreferences.edit();
								editor.remove("sessionid");
								editor.remove("sessionname");
								editor.commit();
								Intent intent1 = new Intent(MemberRecord.this, MainActivity.class);
								startActivity(intent1);
								return;
							}
						});
						dialog.create();
						dialog.show();
					break;
    }
   }
 };
 OnTouchListener touch = new OnTouchListener() {
		
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
			switch (v.getId()) {
			case R.id.tab1:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab1.setPadding(0, 0, 0, 0);
					tab1.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab1.setPadding(2, 2, 2, 2);
					tab1.setColorFilter(111111,Mode.SRC_OVER);
					Intent intent11 = new Intent( MemberRecord.this, MainActivity.class);
					intent11.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent11);
				}
				break;
			case R.id.tab2:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab2.setPadding(2, 2, 2, 2);
					tab2.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab2.setPadding(0, 0, 0, 0);
					tab2.setColorFilter(111111,Mode.SRC_OVER);
				}
				break;
			case R.id.tab3:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab3.setPadding(2, 2, 2, 2);
					tab3.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab3.setPadding(0, 0, 0, 0);
					tab3.setColorFilter(111111,Mode.SRC_OVER);
					Intent intent9 = new Intent(  MemberRecord.this, Search.class);
					intent9.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent9);
				}
				break;
			case R.id.tab4:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab4.setPadding(0, 0, 0, 0);
					tab4.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab4.setPadding(2, 2, 2, 2);
					tab4.setColorFilter(111111,Mode.SRC_OVER);
				}
				break;
			}
			return true;
		}
	};

 private void memberCheckBox() {
	 int checkboxcount = listview.getChildCount(); //checkbox total count
	 int checkedcount = 0;
	 CheckBox listcheckbox;
	 final List<Integer> pklist = new ArrayList<Integer>();
	
	 for ( int i = 0 ; i < checkboxcount ; i ++ ){
		 listcheckbox = (CheckBox) listview.getChildAt(i).findViewById(R.id.showcheckbox);
		 final int selectedpk = (int) listview.getAdapter().getItemId(i);
		 if ( listcheckbox.isChecked()){
			 pklist.add(selectedpk);
			 checkedcount ++;
			 Log.d("---->selectedpk", "-->"+selectedpk);
			 Log.d("---->checkedcount", "-->"+checkedcount);
			 listcheckbox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				 
					public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
						// 체크를 할 때
						if (isChecked) {
							for (int i = 0; i < pklist.size(); i++) {
								if (pklist.get(i) == selectedpk) {
									return;
								}
							}
							pklist.add(selectedpk);
						// 체크가 해제될 때
						} else {
							for (int i =0; i < pklist.size(); i++) {
								if (pklist.get(i) == selectedpk) {
									pklist.remove(i);
									break;
								}
							}
						}
					}
				});
		 }
	 }
	 if( checkedcount > 0 ){
		 AlertDialog.Builder dialog = new AlertDialog.Builder(context);
			dialog.setMessage("Are you Right?");
			dialog.setTitle("Warning");
			dialog.setIcon(R.drawable.icon);
			dialog.setPositiveButton("No", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					return;
				}
			});
			dialog.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					memberDelete((ArrayList<Integer>) pklist);
					String userid = sharedpreferences.getString("sessionid", "");
				    memberSearch(userid);
					return;
				}
			});
			dialog.create();
			dialog.show();
	 }
	 else {
		 AlertDialog.Builder dialog = new AlertDialog.Builder(context);
			dialog.setMessage("Checked please for delete");
			dialog.setTitle("Warning");
			dialog.setIcon(R.drawable.icon);
		    dialog.setNegativeButton("ok", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					return;
				}
			});
			dialog.create();
			dialog.show();
	 }
 }
 private void memberDelete(ArrayList<Integer> pklist){
	 SQLiteDAO obj;
	 obj = new SQLiteDAO( this ); 
	 SQLiteDatabase db = obj.getWritableDatabase();
	 for (Integer id : pklist){
	 String sql = "delete from member where _id = "+id+" ";
	 Log.d("sql =====", "sql--->"+sql);
	 try {
    	 db.execSQL(sql);
	} catch (Exception e) {
		Log.d("----->", e.getMessage());
	}
	 }
	 db.close();
 }
 private void memberSearch(String id){
	 SQLiteDAO obj; //DAO only return after check 
	 obj = new SQLiteDAO( this ); 
	 SQLiteDatabase db = obj.getWritableDatabase(); //db execute -> db cunnect
	 String sql = "select _id,date,position,time from member where id = '"+id+"'";
	 Cursor c = db.rawQuery(sql, null); // = Result Set  -> You have something if rs or c excute
	 startManagingCursor(c);
	 String from[] = new String [] {"_id","date","position","time"};
	 int to[] =  new int [] {R.id.showno,R.id.showdate,R.id.showposition,R.id.showtime};
	 SimpleCursorAdapter adapter = new SimpleCursorAdapter(listview.getContext(),
			 R.layout.member_recorddetail,c,from,to);
	 listview.setAdapter(adapter);
	 listview.setTextFilterEnabled(true);
	 listview.setSelectionFromTop(10,1);
 }
@Override
public void onBackPressed() {
	finish();
	super.onBackPressed();
 }
@Override
public boolean onDown(MotionEvent e) {
	// TODO Auto-generated method stub
	return false;
}
public boolean onTouchEvent(MotionEvent me){
	return gestureScanner.onTouchEvent(me);
}
@Override
public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
	// TODO Auto-generated method stub
	return false;
}
@Override
public void onLongPress(MotionEvent e) {
	// TODO Auto-generated method stub
	
}

@Override
public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
	// TODO Auto-generated method stub
	return false;
}
@Override
public void onShowPress(MotionEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public boolean onSingleTapUp(MotionEvent e) {
	// TODO Auto-generated method stub
	return false;
}
}
 





