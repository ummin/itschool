package com.example.healthproject;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PorterDuff.Mode;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MemberInsertActivity extends Activity implements OnGestureListener{
	EditText id;
	EditText name;
	EditText password;
	
	Button close;
	Button save;
	Button idchk;
	final Context context = this;
	private User user;
	boolean confirmchk = false;
	
	ImageView tab1;
	ImageView tab2;
	ImageView tab3;
	ImageView tab4;
	TextView view;
	LinearLayout baselayout;
	InputMethodManager imm;
	
	private GestureDetector gestureScanner;
//	
	 protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.member_insert);
	        try {
	            getActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
	            getActionBar().setCustomView(R.layout.title);
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }
	        gestureScanner = new GestureDetector(this);
	        id = (EditText) findViewById(R.id.id);
	        name = (EditText) findViewById(R.id.name);
	        password = (EditText) findViewById(R.id.password);
	        close = (Button) findViewById(R.id.close);
	        save = (Button) findViewById(R.id.save);
	        idchk = (Button) findViewById(R.id.idchk);
	        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
	        
	        baselayout = (LinearLayout) findViewById(R.id.baselayout);
	        baselayout.setOnClickListener( bClick );
	        
			close.setOnClickListener( bClick );
			save.setOnClickListener( bClick );
			idchk.setOnClickListener( bClick );
			
			tab1=(ImageView) findViewById(R.id.tab1);
			tab2=(ImageView) findViewById(R.id.tab2);
			tab3=(ImageView) findViewById(R.id.tab3);
			tab4 = (ImageView) findViewById(R.id.tab4);
	        
	        tab1.setOnTouchListener(touch);
			tab2.setOnTouchListener(touch);
			tab3.setOnTouchListener(touch);
			tab2.setVisibility(view.VISIBLE);
			tab4.setVisibility(view.GONE);
			
	 } 
	 
	 OnTouchListener touch = new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (v.getId()) {
				case R.id.tab1:
					if(event.getAction()==MotionEvent.ACTION_DOWN) {
						tab1.setPadding(0, 0, 0, 0);
						tab1.setColorFilter(111111,Mode.SRC_OVER);
					}
					else if (event.getAction()==MotionEvent.ACTION_UP){
						tab1.setPadding(3, 3, 3, 3);
						tab1.setColorFilter(111111,Mode.SRC_OVER);
						Intent intent11 = new Intent( MemberInsertActivity.this, MainActivity.class);
						intent11.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intent11);
					}
					break;
				case R.id.tab2:
					if(event.getAction()==MotionEvent.ACTION_DOWN) {
						tab2.setPadding(0, 0, 0, 0);
						tab2.setColorFilter(111111,Mode.SRC_OVER);
					}
					else if (event.getAction()==MotionEvent.ACTION_UP){
						tab2.setPadding(3, 3, 3, 3);
						tab2.setColorFilter(111111,Mode.SRC_OVER);
						Intent intent8 = new Intent(  MemberInsertActivity.this, MemberLoginActivity.class);
						intent8.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intent8);
					}
					break;
				case R.id.tab3:
					if(event.getAction()==MotionEvent.ACTION_DOWN) {
						tab3.setPadding(0, 0, 0, 0);
						tab3.setColorFilter(111111,Mode.SRC_OVER);
					}
					else if (event.getAction()==MotionEvent.ACTION_UP){
						tab3.setPadding(3, 3, 3, 3 );
						tab3.setColorFilter(111111,Mode.SRC_OVER);
						Intent intent9 = new Intent(  MemberInsertActivity.this, Search.class);
						intent9.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intent9);
					}
					break;
				}
				return true;
			}
		};
		
Button.OnClickListener bClick = new View.OnClickListener() {
	@Override
	public void onClick(View v) {
		imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
		switch (v.getId()) {
		case R.id.close:
				finish();
				break;
		case R.id.idchk:
			if (id.getText().toString().equals("")){
				AlertDialog.Builder dialog = new AlertDialog.Builder(context);
				dialog.setMessage("Input ID");
				dialog.setTitle("Warning");
				dialog.setIcon(R.drawable.icon);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						return;
					}
				});
				dialog.create();
				dialog.show();
			}
			else{
				String idchk1 = id.getText().toString();
				boolean chk = memberIdCheck(idchk1);
				if ( chk  ) {
					AlertDialog.Builder dialog = new AlertDialog.Builder(context);
					dialog.setMessage("ID is duplicated");
					dialog.setTitle("Wait!");
					dialog.setIcon(R.drawable.icon);
					dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							id.setText("");
							confirmchk = false;
							return ;
						}
					});
					dialog.create();
					dialog.show();
				}
				else {
					AlertDialog.Builder dialog = new AlertDialog.Builder(context);
					dialog.setMessage("ID is useful");
					dialog.setTitle("Wait!");
					dialog.setIcon(R.drawable.icon);
					dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							confirmchk = true;
							return ;
						}
					});
					dialog.create();
					dialog.show();
				}
			}
			
			break;
		case R.id.save:
			String message = "";
			if ( id.getText().toString().equals("") || !confirmchk ) {
				 message += " Check ID\n";
			}
		    if ( name.getText().toString().equals("")){
					message += " Check Name\n";
				}
			if ( password.getText().toString().equals("")){
				message += " Check password\n";
			}
			if ( !message.equals("")) {
				AlertDialog.Builder dialog = new AlertDialog.Builder(context);
				dialog.setMessage(message);
				dialog.setTitle("Warning");
				dialog.setIcon(R.drawable.icon);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						return;
					}
				});
				dialog.create();
				dialog.show();
			}
			else {
			user = new User();
			user.setId(id.getText().toString());
			user.setPassword(password.getText().toString());
			user.setName(name.getText().toString());
	        memberInsert( user );
	        finish();
			}
			break;
		
		}
	}
 };
 
 private boolean memberIdCheck(String idchk){
	 boolean chk = false;
	 SQLiteDAO obj; 
	 obj = new SQLiteDAO( this ); 
	 SQLiteDatabase db = obj.getWritableDatabase(); 
	 String sql = "select _id from member where id = '"+idchk+"'";
	 Log.d("---------->","IDCHECK"+sql);
	 try {
		 Cursor cursor = db.rawQuery(sql, null);
		 if(cursor.moveToNext()){
			 chk = true;
		 }
		 db.close();
	} catch (Exception e) {
		chk = false;
		Log.d("====>",e.getMessage());
	}
	 return chk;
 }
 private void memberInsert( User user) {
	 SQLiteDAO obj ;
	 obj =  new SQLiteDAO( this );  //DAO only return after check 
	 Log.d("-----------", "MemberInsert");
	 SQLiteDatabase db = obj.getWritableDatabase(); //db execute
	 String date = " Well   come ";
	 String position = "our member!";
	 String time = "Fighting!";
	 String sql = "insert into member (id,name,password,date,position,time) values(";
	        sql += " '"+user.getId()+"', '"+user.getName()+"', '"+user.getPassword()+"',  ";
	        sql += " '"+date+"', '"+position+"', '"+time+"' )  ";
	        try {
	        	 db.execSQL(sql);
	        	 db.close();
	        	 Log.d("----->", "Do success....."+sql);
			} catch (Exception e) {
				Log.d("----->", "Do Fault....."+sql);
			}
 }
 @Override
 public void onBackPressed() {
	    finish();	
		super.onBackPressed();
	}
@Override
public boolean onDown(MotionEvent e) {
	// TODO Auto-generated method stub
	return false;
}
public boolean onTouchEvent(MotionEvent me){
	return gestureScanner.onTouchEvent(me);
}
@Override
public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
	// TODO Auto-generated method stub
	return false;
}
@Override
public void onLongPress(MotionEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
	// TODO Auto-generated method stub
	return false;
}
@Override
public void onShowPress(MotionEvent e) {
	// TODO Auto-generated method stub
	
}
@Override
public boolean onSingleTapUp(MotionEvent e) {
	// TODO Auto-generated method stub
	return false;
}
}

