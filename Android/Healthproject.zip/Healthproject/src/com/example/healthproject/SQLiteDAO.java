package com.example.healthproject;

import java.io.Reader;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class SQLiteDAO extends SQLiteOpenHelper {
	private static final String DATABASE_NAME = "health.db";
	private static final int 	DATABASE_VERSION=4;
	private Context mContext;
	private Reader reader;
	
	public SQLiteDAO(Context ctx) {
		super(ctx, DATABASE_NAME, null, DATABASE_VERSION);
		this.mContext = ctx;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		StringBuffer sb = new StringBuffer();
		 sb.append("create table member( _id INTEGER PRIMARY KEY AUTOINCREMENT,");
		 sb.append("id varchar,name varchar,password varchar, position varchar,");
		 sb.append("time varchar,date varchar) ");
		String sql = sb.toString();
		db.execSQL(sql);
		Log.d("---------->", "---------->>onCreate table");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP TABLE IF EXISTS member");
		onCreate(db);
		Log.d("---------->", "---------->>onUpgrade");
	}


}
