package com.example.healthproject;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

public class listview extends Activity{
final Context context = this;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.exercise);
	 }
}
