package com.example.healthproject;
	import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PorterDuff.Mode;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

	public class MemberLoginActivity extends Activity implements OnGestureListener{
		SharedPreferences sharedpreferences;
		public static final String MyPREFERENCES = "mPrefs";
		public static final String sessionid = "sessionid";
		public static final String sessionname = "sessionname";
		
		EditText id;
		EditText password;
		TextView idpwd;
		
		Button close;
		Button login;
		Button join;
		final Context context = this;
		private User user;
		InputMethodManager imm;
		
		ImageView tab1;
		ImageView tab2;
		ImageView tab3;
		ImageView tab4;
		TextView view;

		LinearLayout baselayout;
		private GestureDetector gestureScanner;
		
		 protected void onCreate(Bundle savedInstanceState) {
		        super.onCreate(savedInstanceState);
		        try {
		            getActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
		            getActionBar().setCustomView(R.layout.title);
		        } catch (Exception e) {
		            System.out.println(e.getMessage());
		        }
		        setContentView(R.layout.member_login);
		        gestureScanner = new GestureDetector(this);
		        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		        id = (EditText) findViewById(R.id.id);
		        password = (EditText) findViewById(R.id.password);
		        close = (Button) findViewById(R.id.close);
		        login = (Button) findViewById(R.id.login);
		        join = (Button) findViewById(R.id.join);
		        idpwd = (TextView) findViewById(R.id.idpwd);
		        
				close.setOnClickListener( bClick );
				login.setOnClickListener( bClick );
				join.setOnClickListener( bClick );
				idpwd.setOnTouchListener(touch);
		   
				tab1=(ImageView) findViewById(R.id.tab1);
				tab2=(ImageView) findViewById(R.id.tab2);
				tab3=(ImageView) findViewById(R.id.tab3);
				tab4 = (ImageView) findViewById(R.id.tab4);
		        
		        tab1.setOnTouchListener(touch);
				tab2.setOnTouchListener(touch);
				tab3.setOnTouchListener(touch);
				tab2.setVisibility(view.VISIBLE);
		        
				baselayout = (LinearLayout) findViewById(R.id.baselayout);
			    baselayout.setOnClickListener( bClick );
			        
		        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
			    tab2.setVisibility(view.VISIBLE);
			    tab4.setVisibility(view.GONE);
				
		 } 
    
		 OnTouchListener touch = new OnTouchListener() {
				
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (v.getId()) {
					case R.id.idpwd:
						Intent intent = new Intent(MemberLoginActivity.this, MemberFindActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intent);
						break;
					case R.id.tab1:
						if(event.getAction()==MotionEvent.ACTION_DOWN) {
							tab1.setPadding(0, 0, 0, 0);
							tab1.setColorFilter(111111,Mode.SRC_OVER);
						}
						else if (event.getAction()==MotionEvent.ACTION_UP){
							tab1.setPadding(2, 2, 2, 2);
							tab1.setColorFilter(111111,Mode.SRC_OVER);
							Intent intent11 = new Intent( MemberLoginActivity.this, MainActivity.class);
							intent11.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
							startActivity(intent11);
						}
						break;
					case R.id.tab2:
						if(event.getAction()==MotionEvent.ACTION_DOWN) {
							tab2.setPadding(2, 2, 2, 2);
							tab2.setColorFilter(111111,Mode.SRC_OVER);
						}
						else if (event.getAction()==MotionEvent.ACTION_UP){
							tab2.setPadding(0, 0, 0, 0);
							tab2.setColorFilter(111111,Mode.SRC_OVER);
						}
						break;
					case R.id.tab3:
						if(event.getAction()==MotionEvent.ACTION_DOWN) {
							tab3.setPadding(2, 2, 2, 2);
							tab3.setColorFilter(111111,Mode.SRC_OVER);
						}
						else if (event.getAction()==MotionEvent.ACTION_UP){
							tab3.setPadding(0, 0, 0, 0);
							tab3.setColorFilter(111111,Mode.SRC_OVER);
							Intent intent9 = new Intent(  MemberLoginActivity.this, Search.class);
							intent9.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
							startActivity(intent9);
						}
						break;
					}
					return true;
				}
			};
	Button.OnClickListener bClick = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
			switch (v.getId()) {
			case R.id.close:
					finish();
					break;
			case R.id.login:
				String message = "";
				if ( id.getText().toString().equals("")) {
					 message += " Check ID\n";
				}
				if ( password.getText().toString().equals("")){
					message += " Check password\n";
				}
				if ( !message.equals("")) {
					AlertDialog.Builder dialog = new AlertDialog.Builder(context);
					dialog.setMessage(message);
					dialog.setTitle("Warning");
					dialog.setIcon(R.drawable.icon);
					dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							return;
						}
					});
					dialog.create();
					dialog.show();
				}
				else  {
					User user = new User();
					user.setId(id.getText().toString());
					user.setPassword(password.getText().toString());
					memberLogin(user);
				}
				break;
			case R.id.join:
				Intent intent = new Intent(MemberLoginActivity.this, MemberInsertActivity.class);
				startActivity(intent);
				break;
				
			}
		}
	 };
	 private void memberLogin( User user ) {
		 SQLiteDAO obj; //DAO only return after check 
		 obj = new SQLiteDAO( this ); 
		 SQLiteDatabase db = obj.getWritableDatabase(); //db execute
		 String sql = "select id,name from member where id = '"+user.getId()+"' and password = '"+user.getPassword()+"' ";
		        try {
		        	Cursor cursor = db.rawQuery(sql, null);
		        	if(cursor.moveToNext()){
		              SharedPreferences.Editor editor1 = sharedpreferences.edit(); //editor(session) is space
		              editor1.putString(sessionid, cursor.getString(0)); //ssesionid input editor
		              editor1.putString(sessionname, cursor.getString(1));
		        	  editor1.commit(); //Inputdata save in session
		        	  AlertDialog.Builder dialog = new AlertDialog.Builder(context);
		   			  dialog.setMessage("Hello "+user.getId());
		   			  dialog.setTitle("Wellcome");
		   			  dialog.setIcon(R.drawable.icon);
		   			  dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
		   				  
		   				  @Override
		   				  public void onClick(DialogInterface dialog, int which) {
		   					 Intent intent = new Intent(MemberLoginActivity.this, MainActivity.class);
		   					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
		   					 startActivity(intent);
		   					  return ;
		   				  }
		   					  
		   			  });
		   			  dialog.create();
		   			  dialog.show();
		        	}
		        	else{
		        		AlertDialog.Builder dialog = new AlertDialog.Builder(context);
			   			  dialog.setMessage("Check your Id or Password");
			   			  dialog.setTitle("Sorry");
			   			  dialog.setIcon(R.drawable.ic_launcher);
			   			  dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
			   				  
			   				  @Override
			   				  public void onClick(DialogInterface dialog, int which) {
			   					id.setText("");
			   					password.setText("");
			   					  return ;
			   				  }
			   			 });
			   			  dialog.create();
			   			  dialog.show();
		        	}
				} catch (Exception e) {
					Log.d("----->", "Do Fault....."+e.getMessage());
				}
	 }
	 @Override
	  public void onBackPressed() {
		    finish();
	 		super.onBackPressed();
	 	}
	@Override
	public boolean onDown(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean onTouchEvent(MotionEvent me){
		return gestureScanner.onTouchEvent(me);
	}
	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void onLongPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void onShowPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean onSingleTapUp(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}
	}


