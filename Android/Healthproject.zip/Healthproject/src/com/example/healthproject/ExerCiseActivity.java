package com.example.healthproject;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff.Mode;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.TextView;

public class ExerCiseActivity extends Activity implements OnGestureListener{
	ImageView chest;
	ImageView back;
	ImageView sholder;
	ImageView arm;
	ImageView abs;
	ImageView under;
	ImageView full;
	ImageView str;
	ImageView topimage;
	ImageView tab1;
	ImageView tab2;
	ImageView tab3;
	ImageView tab4;
	TextView view;
	
	SharedPreferences sharedpreferences; //Read session data
	public static final String MyPREFERENCES = "mPrefs"; //Read session data
	private GestureDetector gestureScanner;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		try {
            getActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
            getActionBar().setCustomView(R.layout.title);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
		setContentView(R.layout.exercise);
		gestureScanner = new GestureDetector(this);
		chest = (ImageView) findViewById(R.id.chest);
		back = (ImageView) findViewById(R.id.back);
		sholder = (ImageView) findViewById(R.id.sholder);
		arm = (ImageView) findViewById(R.id.arm);
		abs = (ImageView) findViewById(R.id.abs);
		under = (ImageView) findViewById(R.id.under);
		full = (ImageView) findViewById(R.id.full);
		str = (ImageView) findViewById(R.id.str);
		topimage = (ImageView) findViewById(R.id.topimage);
		
		tab1=(ImageView) findViewById(R.id.tab1);
		tab2=(ImageView) findViewById(R.id.tab2);
		tab3=(ImageView) findViewById(R.id.tab3);
		tab4 = (ImageView) findViewById(R.id.tab4);
		
		tab1.setOnTouchListener(touch);
		tab2.setOnTouchListener(touch);
		tab3.setOnTouchListener(touch);
		tab2.setVisibility(view.VISIBLE);
		
		chest.setOnTouchListener(touch);
		back.setOnTouchListener(touch);
		sholder.setOnTouchListener(touch);
		arm.setOnTouchListener(touch);
		abs.setOnTouchListener(touch);
		under.setOnTouchListener(touch);
		full.setOnTouchListener(touch);
		str.setOnTouchListener(touch);
		
		sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
		String login = sharedpreferences.getString("sessionid", "");
		if(!login.equals("")){
			Log.d("---login---", login);
			tab2.setVisibility(view.GONE);
			tab4.setVisibility(view.VISIBLE);
			tab4.setOnTouchListener(touch);
		}
		else{
			tab2.setVisibility(view.VISIBLE);
			tab4.setVisibility(view.GONE);
		}
	}
		OnTouchListener touch = new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (v.getId()) {
				case R.id.chest:
					if(event.getAction()==MotionEvent.ACTION_DOWN) {
						chest.setPadding(0, 0, 0, 0);
						chest.setColorFilter(111111,Mode.SRC_OVER);
					}
					else if (event.getAction()==MotionEvent.ACTION_UP){
						chest.setPadding(3, 3, 3, 3);
						chest.setColorFilter(111111,Mode.SRC_OVER);
						String videoId = "7VTpow7lu6s";
						Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+videoId)); 
						intent.putExtra("VIDEO_ID", videoId); 
						intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intent); 
					}
					break;
				case R.id.arm:
					if(event.getAction()==MotionEvent.ACTION_DOWN) {
						arm.setPadding(0, 0, 0, 0);
						arm.setColorFilter(111111,Mode.SRC_OVER);
					}
					else if (event.getAction()==MotionEvent.ACTION_UP){
						arm.setPadding(3, 3, 3, 3);
						arm.setColorFilter(111111,Mode.SRC_OVER);
						String videoId1 = "9p0-82GtO1E";
						Intent intent1 = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+videoId1)); 
						intent1.putExtra("VIDEO_ID", videoId1); 
						intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intent1); 
					}
					break;
				case R.id.sholder:
					
					if(event.getAction()==MotionEvent.ACTION_DOWN) {
						sholder.setPadding(0, 0, 0, 0);
						sholder.setColorFilter(111111,Mode.SRC_OVER);
					}
					else if (event.getAction()==MotionEvent.ACTION_UP){
						sholder.setPadding(3, 3, 3, 3);
						sholder.setColorFilter(111111,Mode.SRC_OVER);
						String videoId2 = "XtwWRuzOmHM";
						Intent intent2 = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+videoId2)); 
						intent2.putExtra("VIDEO_ID", videoId2); 
						intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intent2); 
					}
					break;
				case R.id.back:
					
					if(event.getAction()==MotionEvent.ACTION_DOWN) {
						back.setPadding(0, 0, 0, 0);
						back.setColorFilter(111111,Mode.SRC_OVER);
					}
					else if (event.getAction()==MotionEvent.ACTION_UP){
						back.setPadding(3, 3, 3, 3);
						back.setColorFilter(111111,Mode.SRC_OVER);
						String videoId3 = "beueQe98DiE";
						Intent intent3 = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+videoId3)); 
						intent3.putExtra("VIDEO_ID", videoId3); 
						intent3.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intent3); 
					}
					break;
			case R.id.abs:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					abs.setPadding(0, 0, 0, 0);
					abs.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					abs.setPadding(3, 3, 3, 3);
					abs.setColorFilter(111111,Mode.SRC_OVER);
					String videoId4 = "L9433hhTlkQ";
					Intent intent4 = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+videoId4)); 
					intent4.putExtra("VIDEO_ID", videoId4); 
					intent4.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent4); 
				}
				break;
			case R.id.full:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					full.setPadding(0, 0, 0, 0);
					full.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					full.setPadding(3, 3, 3, 3);
					full.setColorFilter(111111,Mode.SRC_OVER);
					String videoId5 = "JaUt6wz6vnQ";
					Intent intent5 = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+videoId5)); 
					intent5.putExtra("VIDEO_ID", videoId5); 
					intent5.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent5); 
				}
				break;
			case R.id.under:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					under.setPadding(0, 0, 0, 0);
					under.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					under.setPadding(3, 3, 3, 3);
					under.setColorFilter(111111,Mode.SRC_OVER);
					String videoId6 = "xpzMr3nSOIE";
					Intent intent6 = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+videoId6)); 
					intent6.putExtra("VIDEO_ID", videoId6); 
					intent6.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent6); 
				}
				break;
			case R.id.str:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					str.setPadding(0, 0, 0, 0);
					str.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					str.setPadding(3, 3, 3, 3);
					str.setColorFilter(111111,Mode.SRC_OVER);
					String videoId7 = "SAsE6JUbSWQ";
					Intent intent7 = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+videoId7)); 
					intent7.putExtra("VIDEO_ID", videoId7); 
					intent7.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent7); 
				}
				break;
			case R.id.tab1:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab1.setPadding(0, 0, 0, 0);
					tab1.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab1.setPadding(3, 3, 3, 3);
					tab1.setColorFilter(111111,Mode.SRC_OVER);
				}
				Intent intent11 = new Intent( ExerCiseActivity.this, MainActivity.class);
				intent11.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
				startActivity(intent11);
					break;
			case R.id.tab2:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab2.setPadding(0, 0, 0, 0);
					tab2.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab2.setPadding(3, 3, 3, 3);
					tab2.setColorFilter(111111,Mode.SRC_OVER);
				}
				Intent intent8 = new Intent( ExerCiseActivity.this, MemberLoginActivity.class);
				intent8.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
				startActivity(intent8);
					break;
			case R.id.tab3:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab3.setPadding(0, 0, 0, 0);
					tab3.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab3.setPadding(3, 3, 3, 3 );
					tab3.setColorFilter(111111,Mode.SRC_OVER);
				}
				Intent intent9 = new Intent( ExerCiseActivity.this, Search.class);
				intent9.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
				startActivity(intent9);
					break;
			case R.id.tab4:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab4.setPadding(0, 0, 0, 0);
					tab4.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab4.setPadding(2, 2, 2, 2);
					tab4.setColorFilter(111111,Mode.SRC_OVER);
				}
					Intent intent10 = new Intent( ExerCiseActivity.this, MemberRecord.class);
					intent10.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent10);
					break;
				}
				return true;
			}
		};
		@Override
		 public void onBackPressed() {
				finish();
				super.onBackPressed();
			}
		@Override
		public boolean onDown(MotionEvent e) {
			// TODO Auto-generated method stub
			return false;
		}
		public boolean onTouchEvent(MotionEvent me){
			return gestureScanner.onTouchEvent(me);
		}
		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
			// TODO Auto-generated method stub
			return false;
		}
		@Override
		public void onLongPress(MotionEvent e) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
			// TODO Auto-generated method stub
			return false;
		}
		@Override
		public void onShowPress(MotionEvent e) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public boolean onSingleTapUp(MotionEvent e) {
			// TODO Auto-generated method stub
			return false;
		}
}
