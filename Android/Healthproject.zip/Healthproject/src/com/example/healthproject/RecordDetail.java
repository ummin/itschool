package com.example.healthproject;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PorterDuff.Mode;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class RecordDetail extends Activity implements OnGestureListener {
	Button close;
	Button record;
	LinearLayout baselayout;
	
	Button positionlist;
	Button timelist;
	Dialog Dialog;
	
	TextView date;
	TextView position;
	TextView time;
	TextView userv;
	InputMethodManager imm;
	
	ImageView tab1;
	ImageView tab2;
	ImageView tab3;
	ImageView tab4;
	TextView view;
	
	final Context context = this;
	SharedPreferences sharedpreferences; //Read session data
 	public static final String MyPREFERENCES = "mPrefs"; //Read session data
 	private GestureDetector gestureScanner;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.record_view);
	        gestureScanner = new GestureDetector(this);
	        try {
	            getActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
	            getActionBar().setCustomView(R.layout.title);
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }
	        baselayout = (LinearLayout) findViewById(R.id.baselayout);
	        positionlist = (Button) findViewById(R.id.positionlist);
	        timelist = (Button) findViewById(R.id.timelist);
	        close = (Button) findViewById(R.id.close);
	        record = (Button) findViewById(R.id.record);
	        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
	        date = (TextView) findViewById(R.id.date);
	        position = (TextView) findViewById(R.id.position);
	        time = (TextView) findViewById(R.id.time);
	        userv = (TextView) findViewById(R.id.userv);
	        
//	        positionlist.setOnClickListener(bClick);
//	        timelist.setOnClickListener(bClick);
	        close.setOnClickListener(bClick);
	        record.setOnClickListener(bClick);
	        
	        baselayout.setOnClickListener(bClick);
	        baselayout = (LinearLayout) findViewById(R.id.baselayout);
	        
	        position.setOnTouchListener(touch);
	        time.setOnTouchListener(touch);
	        
	        tab1=(ImageView) findViewById(R.id.tab1);
			tab2=(ImageView) findViewById(R.id.tab2);
			tab3=(ImageView) findViewById(R.id.tab3);
			tab4 = (ImageView) findViewById(R.id.tab4);
	        
	        tab1.setOnTouchListener(touch);
			tab2.setOnTouchListener(touch);
			tab3.setOnTouchListener(touch);
			tab2.setVisibility(view.VISIBLE);
	        
	    	sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
	        String userid = sharedpreferences.getString("sessionid", "");	        
	        String inputdate = CustomDateFormat.dateFormat();
	        date.setText(inputdate);
	        userv.setText(userid);
	        tab2.setVisibility(view.GONE);
			tab4.setVisibility(view.VISIBLE);
			tab4.setOnTouchListener(touch);
	 }
	
	Button.OnClickListener bClick = new View.OnClickListener() {
		@Override
				public void onClick(View v) {
			switch(v.getId()){
			case R.id.close:
				finish();
				break;
			case R.id.record:
				String message = "";
				if (position.getText().toString().equals("")){
					message += "Select position\n";
				}
				if (time.getText().toString().equals("")){
					message += "Select Time ";
				}
				if (!message.equals("")){
				AlertDialog.Builder dialog = new AlertDialog.Builder(context);
				dialog.setMessage(message);
				dialog.setTitle("Warning");
				dialog.setIcon(R.drawable.icon);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						return;
					}
				});
				dialog.create();
				dialog.show();
				}
				else {
					AlertDialog.Builder dialog = new AlertDialog.Builder(context);
					dialog.setMessage("Are you right?");
					dialog.setTitle("Warning");
					dialog.setIcon(R.drawable.icon);
					dialog.setPositiveButton("No", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							return;
						}
					});
					dialog.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							User user = new User();
							user.setDate((String) date.getText());
							user.setPosition((String) position.getText());
							user.setTime((String) time.getText());
							user.setId((String) userv.getText());
							MemberUpdate(user);
							finish();
							return;
						}
					});
					dialog.create();
					dialog.show();
				}
				break;
			}
		}
	};
	
OnTouchListener touch = new OnTouchListener() {
		
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			switch (v.getId()) {
			case R.id.tab1:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab1.setPadding(0, 0, 0, 0);
					tab1.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab1.setPadding(3, 3, 3, 3);
					tab1.setColorFilter(111111,Mode.SRC_OVER);
					Intent intent11 = new Intent( RecordDetail.this, MainActivity.class);
					intent11.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent11);
				}
				break;
			case R.id.tab2:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab2.setPadding(0, 0, 0, 0);
					tab2.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab2.setPadding(3, 3, 3, 3);
					tab2.setColorFilter(111111,Mode.SRC_OVER);
					Intent intent8 = new Intent(  RecordDetail.this, MemberRecord.class);
					intent8.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent8);
				}
				break;
			case R.id.tab3:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab3.setPadding(0, 0, 0, 0);
					tab3.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab3.setPadding(3, 3, 3, 3 );
					tab3.setColorFilter(111111,Mode.SRC_OVER);
					Intent intent9 = new Intent(  RecordDetail.this, Search.class);
					intent9.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent9);
				}
				break;
			case R.id.tab4:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					tab4.setPadding(0, 0, 0, 0);
					tab4.setColorFilter(111111,Mode.SRC_OVER);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					tab4.setPadding(2, 2, 2, 2);
					tab4.setColorFilter(111111,Mode.SRC_OVER);
					Intent intent10 = new Intent(  RecordDetail.this, MemberRecord.class);
					intent10.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
					startActivity(intent10);
				}
				break;
			case R.id.position:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					position.setPadding(0, 0, 0, 0);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					position.setPadding(2, 2, 2, 2);
					positionSelect();
				}
				break;
			case R.id.time:
				if(event.getAction()==MotionEvent.ACTION_DOWN) {
					time.setPadding(0, 0, 0, 0);
				}
				else if (event.getAction()==MotionEvent.ACTION_UP){
					time.setPadding(2, 2, 2, 2);
					timeSelect();
				}
				break;
			}
			return true;
		}
	};

	private void positionSelect(){
		AlertDialog.Builder alertBuilder = new AlertDialog.Builder(
                RecordDetail.this);
        alertBuilder.setIcon(R.drawable.icon);
        alertBuilder.setTitle("Select position");

        // List Adapter 생성
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                RecordDetail.this,
                android.R.layout.select_dialog_singlechoice);
        adapter.add("Chest");
        adapter.add("Shoulder");
        adapter.add("Arm");
        adapter.add("Abs");
        adapter.add("Back");
        adapter.add("Under");
        adapter.add("Full");
        adapter.add("Stretching");
        // 버튼 생성
        alertBuilder.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                            int which) {
                        dialog.dismiss();
                       
                    }
                });
        alertBuilder.setAdapter(adapter,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // AlertDialog 안에 있는 AlertDialog
                    	String select = adapter.getItem(id);
                        AlertDialog.Builder innBuilder = new AlertDialog.Builder(RecordDetail.this);
                        innBuilder.setMessage(select);
                        innBuilder.setTitle("Your Choice ");
                        innBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                           }
                         });
                        innBuilder.show();
                        position.setText(select);
                    }
                });
        alertBuilder.show();
	}
	
	private void timeSelect() {
		AlertDialog.Builder alertBuilder1 = new AlertDialog.Builder(
                RecordDetail.this);
        alertBuilder1.setIcon(R.drawable.icon);
        alertBuilder1.setTitle("Select time");

        // List Adapter 생성
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                RecordDetail.this,
                android.R.layout.select_dialog_singlechoice);
        for ( int i = 1 ; i <=40 ; i ++){
        	int timeend = i*5;
        adapter.add(timeend+" Minute");
        }
        // 버튼 생성
        alertBuilder1.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                            int which) {
                        dialog.dismiss();
                       
                    }
                });
        alertBuilder1.setAdapter(adapter,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // AlertDialog 안에 있는 AlertDialog
                    	String select = adapter.getItem(id);
                    	Log.d("------->", "TIME->"+select);
                        AlertDialog.Builder innBuilder = new AlertDialog.Builder(RecordDetail.this);
                        innBuilder.setMessage(select);
                        innBuilder.setTitle("Your Choice ");
                        innBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                          dialog.dismiss();
                           }
                         });
                        innBuilder.show();
                        time.setText(select);
                    }
                });
        alertBuilder1.show();
	}
	 private void MemberUpdate(User user) {
		 SQLiteDAO obj; //DAO only return after check 
		 obj = new SQLiteDAO( this ); 
		 SQLiteDatabase db = obj.getWritableDatabase(); //db execute
		 String sql = "insert into member (id,date,position,time) values('"+user.getId()+"', "; 
		 		sql += " '"+user.getDate()+"', '"+user.getPosition()+"','"+user.getTime()+"' ) ";
		 		try {
		        	 db.execSQL(sql);
		        	 db.close();
				} catch (Exception e) {
					Log.d("----->", e.getMessage());
				}
	 	}
	 @Override
	  public void onBackPressed() {
		    finish();
	 		super.onBackPressed();
	 	}
	@Override
	public boolean onDown(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean onTouchEvent(MotionEvent me){
		return gestureScanner.onTouchEvent(me);
	}
	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void onLongPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void onShowPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean onSingleTapUp(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}
}
